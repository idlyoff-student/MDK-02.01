document.addEventListener('DOMContentLoaded', function() {
    // Плавная прокрутка для якорных ссылок
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                window.scrollTo({
                    top: target.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Анимация для элементов при прокрутке страницы
    const fadeInElements = document.querySelectorAll('.gallery-item, .testimonial-item, .product-card, .feature-item, .about-image, .section-header');
    const animationObserver = new IntersectionObserver(
        (entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Добавляем задержку для каскадной анимации
                    setTimeout(() => {
                        entry.target.classList.add('fade-in');
                    }, entry.target.dataset.delay || 0);
                    
                    // Отключаем наблюдение после анимации
                    observer.unobserve(entry.target);
                }
            });
        },
        { threshold: 0.15 }
    );
    
    // Добавляем изначальный класс для анимации и назначаем задержки
    fadeInElements.forEach((element, index) => {
        element.classList.add('fade-element');
        
        // Назначаем задержку, если элемент находится в группе
        const parent = element.parentNode;
        if (parent && parent.children.length > 1) {
            const siblingIndex = Array.from(parent.children).indexOf(element);
            element.dataset.delay = siblingIndex * 150; // 150ms задержка между элементами
        }
        
        // Запускаем наблюдатель
        animationObserver.observe(element);
    });

    // Табы в галерее с анимацией
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Удаляем активный класс у всех кнопок и содержимого
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => {
                content.style.opacity = '0';
                content.style.transform = 'translateY(20px)';
                
                // Сначала скрываем текущий контент с анимацией
                setTimeout(() => {
                    content.classList.remove('active');
                    
                    // Затем показываем новый контент
                    if (content.id === tabId) {
                        content.classList.add('active');
                        
                        // И анимируем его появление
                        setTimeout(() => {
                            content.style.opacity = '1';
                            content.style.transform = 'translateY(0)';
                        }, 50);
                    }
                }, 300);
            });
            
            // Добавляем активный класс к нажатой кнопке
            this.classList.add('active');
        });
    });
    
    // Инициализация первого таба
    if (tabContents.length > 0 && tabContents[0].classList.contains('active')) {
        tabContents[0].style.opacity = '1';
        tabContents[0].style.transform = 'translateY(0)';
    }

    // Улучшенный слайдер отзывов - статичный
    const testimonialSlider = document.querySelector('.testimonials-slider');
    const testimonialItems = document.querySelectorAll('.testimonial-item');
    const dots = document.querySelectorAll('.dot');

    if (testimonialSlider && testimonialItems.length > 0) {
        // Удаляем все клоны, если они есть
        testimonialSlider.querySelectorAll('.testimonial-item.clone').forEach(clone => clone.remove());
        
        // Работаем только с оригинальными элементами
        const originalItems = Array.from(testimonialSlider.querySelectorAll('.testimonial-item'));
        
        // Наведение на отзыв выделяет соответствующую точку
        originalItems.forEach((item, index) => {
            item.addEventListener('mouseenter', () => {
                dots.forEach((dot, i) => {
                    dot.classList.toggle('active', i === index);
                });
            });
        });
        
        // Клик по точке подсвечивает соответствующий отзыв
        dots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                // Удаляем активное состояние у всех отзывов
                originalItems.forEach(item => {
                    item.style.boxShadow = '';
                    item.style.transform = '';
                });
                
                // Добавляем активное состояние текущему отзыву
                if (originalItems[index]) {
                    originalItems[index].style.boxShadow = '0 10px 25px rgba(139, 69, 19, 0.4)';
                    originalItems[index].style.transform = 'translateY(-10px)';
                    
                    // Обновляем активные точки
                    dots.forEach((d, i) => {
                        d.classList.toggle('active', i === index);
                    });
                }
            });
        });
    }

    // Бренды - бесконечная карусель
    const brandsSlider = document.querySelector('.brands-slider');

    if (brandsSlider) {
        const brandItems = Array.from(brandsSlider.querySelectorAll('.brand-item'));
        
        // Создаем новый контейнер, если его еще нет
        let brandsContainer = document.querySelector('.brands-container');
        if (!brandsContainer) {
            brandsContainer = document.createElement('div');
            brandsContainer.className = 'brands-container';
            brandsSlider.parentNode.insertBefore(brandsContainer, brandsSlider);
            brandsContainer.appendChild(brandsSlider);
        }
        
        // Очищаем слайдер от дублированных элементов
        const originalItems = Array.from(brandsSlider.querySelectorAll('.brand-item:not(.clone)'));
        if (originalItems.length === 0) {
            // Если оригинальных элементов нет, значит все текущие - оригиналы
            brandItems.forEach(item => item.classList.remove('clone'));
        } else {
            // Удаляем все клоны
            brandsSlider.querySelectorAll('.brand-item.clone').forEach(clone => clone.remove());
        }
        
        // Добавляем клоны для создания эффекта бесконечной карусели
        const itemsToClone = brandsSlider.querySelectorAll('.brand-item');
        
        itemsToClone.forEach(item => {
            const clone = item.cloneNode(true);
            clone.classList.add('clone');
            brandsSlider.appendChild(clone);
        });
        
        // Устанавливаем обработчик для перезапуска анимации после завершения
        brandsSlider.addEventListener('animationiteration', () => {
            // Можно добавить логику для плавного перезапуска анимации если нужно
            console.log('Iteration completed');
        });
    }

    // Обработка фильтров в каталоге
    const filterLinks = document.querySelectorAll('.filter-group ul li a');
    
    filterLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Удаляем активный класс у всех ссылок
            filterLinks.forEach(item => {
                item.classList.remove('active');
            });
            
            // Добавляем активный класс к нажатой ссылке
            this.classList.add('active');
            
            // Здесь должна быть логика фильтрации товаров
            const category = this.textContent.trim().toLowerCase();
            filterProducts(category);
        });
    });
    
    // Функция для фильтрации товаров с анимацией
    function filterProducts(category) {
        const products = document.querySelectorAll('.product-card');
        
        products.forEach(product => {
            const productTitle = product.querySelector('h3').textContent.toLowerCase();
            
            // Анимация исчезновения
            if (category !== 'все' && !productTitle.includes(category)) {
                product.style.opacity = '0';
                product.style.transform = 'scale(0.8)';
                
                setTimeout(() => {
                    product.style.display = 'none';
                }, 300);
            } else {
                // Сначала делаем элемент видимым
                product.style.display = 'block';
                
                // Затем анимируем его появление (в следующем кадре)
                setTimeout(() => {
                    product.style.opacity = '1';
                    product.style.transform = 'scale(1)';
                }, 10);
            }
        });
    }

    // Обработка сортировки в каталоге
    const sortSelect = document.getElementById('sort-select');
    
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            const sortType = this.value;
            sortProducts(sortType);
        });
    }
    
    // Функция для сортировки товаров с анимацией
    function sortProducts(sortType) {
        const productsContainer = document.querySelector('.catalog-grid');
        const products = Array.from(document.querySelectorAll('.product-card'));
        
        // Сначала скрываем все элементы
        products.forEach(product => {
            product.style.opacity = '0';
            product.style.transform = 'translateY(20px)';
        });
        
        // Сортируем элементы
        products.sort((a, b) => {
            const priceA = parseFloat(a.querySelector('.product-price').textContent.replace(/[^\d.-]/g, ''));
            const priceB = parseFloat(b.querySelector('.product-price').textContent.replace(/[^\d.-]/g, ''));
            
            if (sortType === 'price-asc') {
                return priceA - priceB;
            } else if (sortType === 'price-desc') {
                return priceB - priceA;
            } else {
                return 0;
            }
        });
        
        // Очищаем контейнер
        productsContainer.innerHTML = '';
        
        // Добавляем отсортированные элементы обратно с задержкой для каскадной анимации
        products.forEach((product, index) => {
            productsContainer.appendChild(product);
            
            // Анимируем появление с задержкой
            setTimeout(() => {
                product.style.opacity = '1';
                product.style.transform = 'translateY(0)';
            }, index * 50);
        });
    }

    // Обработка формы обратной связи
    const contactForm = document.getElementById('feedback-form');
    const subscribeForm = document.querySelector('.subscribe-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Получаем данные формы
            const formData = new FormData(this);
            const formValues = {};
            
            for (let [key, value] of formData.entries()) {
                formValues[key] = value;
            }
            
            // В реальном проекте здесь был бы AJAX-запрос для отправки данных на сервер
            console.log('Отправка данных формы:', formValues);
            
            // Имитация успешной отправки с анимацией
            const btn = this.querySelector('button[type="submit"]');
            const originalText = btn.innerHTML;
            
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Отправка...';
            
            setTimeout(() => {
                showNotification('Спасибо за ваше сообщение! Мы свяжемся с вами в ближайшее время.');
                
                // Восстанавливаем кнопку
                btn.innerHTML = originalText;
                btn.disabled = false;
                
                // Сбрасываем форму
                this.reset();
            }, 1500);
        });
    }

    // Обработка формы подписки
    if (subscribeForm) {
        subscribeForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Получаем email
            const email = this.querySelector('input[type="email"]').value;
            
            // Анимация отправки
            const btn = this.querySelector('button');
            const originalText = btn.innerHTML;
            
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            
            setTimeout(() => {
                // Имитация успешной подписки
                showNotification('Спасибо за подписку! Ваш промокод на скидку 20%: TSUM2024', 'success');
                
                // Восстанавливаем кнопку
                btn.innerHTML = originalText;
                btn.disabled = false;
                
                // Сбрасываем форму
                this.reset();
            }, 1500);
        });
    }

    // Кнопка "Купить" для товаров с анимацией
    const buyButtons = document.querySelectorAll('.btn-add-cart');
    
    buyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const product = this.closest('.product-card');
            const productName = product.querySelector('h3').textContent;
            
            // Анимация кнопки
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            
            setTimeout(() => {
                this.innerHTML = '<i class="fas fa-check"></i> Добавлено';
                
                // Через некоторое время возвращаем исходный текст
                setTimeout(() => {
                    this.innerHTML = originalText;
                }, 1500);
                
                // Показываем уведомление
                showNotification(`Товар "${productName}" добавлен в корзину!`, 'success');
            }, 700);
        });
    });

    // Улучшенная функция для показа уведомления
    function showNotification(message, type = 'info') {
        // Создаем элемент уведомления
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        
        // Определяем иконку в зависимости от типа уведомления
        let icon = 'info-circle';
        if (type === 'success') icon = 'check-circle';
        if (type === 'error') icon = 'exclamation-circle';
        if (type === 'warning') icon = 'exclamation-triangle';
        
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-${icon}"></i>
                <p>${message}</p>
            </div>
            <button class="notification-close"><i class="fas fa-times"></i></button>
        `;
        
        // Добавляем стили
        const style = document.createElement('style');
        if (!document.querySelector('style.notification-styles')) {
            style.className = 'notification-styles';
            style.textContent = `
                .notification {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    background: white;
                    border-radius: 4px;
                    padding: 15px 20px;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                    z-index: 1000;
                    min-width: 300px;
                    transform: translateY(100px);
                    opacity: 0;
                    transition: all 0.3s ease;
                }
                .notification-info {
                    border-left: 4px solid #3498db;
                }
                .notification-success {
                    border-left: 4px solid #2ecc71;
                }
                .notification-error {
                    border-left: 4px solid #e74c3c;
                }
                .notification-warning {
                    border-left: 4px solid #f39c12;
                }
                .notification-content {
                    display: flex;
                    align-items: center;
                }
                .notification-info .notification-content i {
                    color: #3498db;
                }
                .notification-success .notification-content i {
                    color: #2ecc71;
                }
                .notification-error .notification-content i {
                    color: #e74c3c;
                }
                .notification-warning .notification-content i {
                    color: #f39c12;
                }
                .notification-content i {
                    font-size: 1.5rem;
                    margin-right: 10px;
                }
                .notification-close {
                    background: transparent;
                    border: none;
                    font-size: 1rem;
                    cursor: pointer;
                    opacity: 0.5;
                    transition: opacity 0.3s ease;
                }
                .notification-close:hover {
                    opacity: 1;
                }
                .notification.show {
                    transform: translateY(0);
                    opacity: 1;
                }
            `;
            document.head.appendChild(style);
        }
        
        // Добавляем уведомление в DOM
        document.body.appendChild(notification);
        
        // Показываем уведомление
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // Устанавливаем таймер для автоматического закрытия
        const timer = setTimeout(() => {
            closeNotification(notification);
        }, 5000);
        
        // Обработчик для кнопки закрытия
        notification.querySelector('.notification-close').addEventListener('click', () => {
            clearTimeout(timer);
            closeNotification(notification);
        });
        
        // Функция для закрытия уведомления
        function closeNotification(element) {
            element.classList.remove('show');
            setTimeout(() => {
                element.remove();
            }, 300);
        }
    }

    // Обработка пагинации
    const paginationLinks = document.querySelectorAll('.pagination a');
    
    paginationLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Удаляем активный класс у всех ссылок
            paginationLinks.forEach(item => {
                item.classList.remove('active');
            });
            
            // Добавляем активный класс к нажатой ссылке, если это не "Далее"
            if (!this.classList.contains('next')) {
                this.classList.add('active');
            }
            
            // В реальном проекте здесь был бы AJAX-запрос для загрузки следующей страницы товаров
            // Имитация загрузки
            const catalogGrid = document.querySelector('.catalog-grid');
            if (catalogGrid) {
                // Анимация исчезновения
                catalogGrid.style.opacity = '0';
                
                setTimeout(() => {
                    // Имитация загрузки новых данных
                    console.log('Переход на страницу:', this.textContent);
                    
                    // Анимация появления
                    setTimeout(() => {
                        catalogGrid.style.opacity = '1';
                    }, 300);
                }, 500);
            }
        });
    });
}); 