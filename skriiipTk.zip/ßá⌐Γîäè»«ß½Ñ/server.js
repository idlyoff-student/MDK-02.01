const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { JSDOM } = require('jsdom');

const app = express();
const PORT = process.env.PORT || 3000;

// Настройка хранилища для загрузки изображений
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'books/');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// Функция для добавления книг напрямую в базу данных
function addInitialBooks(db) {
  console.log('Добавление начальных книг напрямую в базу данных...');
  
  // Массив с данными книг
  const books = [
    {
      title: "Медвежий угол",
      author: "Фредерик Бакман",
      genre: "Проза для взрослых",
      price: 914,
      image: "10.jpg",
      is_new: 0,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Бог злости",
      author: "Кент Рина",
      genre: "Фантастика",
      price: 660,
      image: "8.jpg",
      is_new: 0,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Если все кошки в мире исчезнут",
      author: "Кавамура Генки",
      genre: "Японская литература",
      price: 340,
      image: "7.jpg",
      is_new: 0,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Скорбь Сатаны",
      author: "Мария Корелли",
      genre: "Проза для взрослых",
      price: 367,
      image: "9.jpg",
      is_new: 0,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Маленький принц",
      author: "Сент-Экзюпери Антуан",
      genre: "Детская литература",
      price: 499,
      image: "1.jpg",
      is_new: 0,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Разреши любить",
      author: "Анна Джейн",
      genre: "Романтика",
      price: 599,
      image: "2.jpg",
      is_new: 0,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Нарциссический абьюз",
      author: "Араби Шахида",
      genre: "Психология",
      price: 779,
      image: "3.jpg",
      is_new: 0,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Спеши любить",
      author: "Николай Спаркс",
      genre: "Проза",
      price: 275,
      image: "4.jpg",
      is_new: 0,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Продажное королевство",
      author: "Бардуго Ли",
      genre: "Романтика",
      price: 1223,
      image: "5.jpg",
      is_new: 0,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Монологи о наслаждении, апатии и смерти",
      author: "Рю Мураками",
      genre: "Японская литература",
      price: 1157,
      image: "6.jpg",
      is_new: 0,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Амур и психея",
      author: "Дана Делон",
      genre: "Романтика",
      price: 341,
      image: "11.jpg",
      is_new: 1,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Мой хулиган",
      author: "Алена Черничная",
      genre: "Романтика",
      price: 367,
      image: "12.jpg",
      is_new: 1,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Она и ее кот",
      author: "Синкай Макото, Нагакава Наруки",
      genre: "Молодежная проза",
      price: 423,
      image: "13.jpg",
      is_new: 1,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    },
    {
      title: "Империя проклятых",
      author: "Кристофф Джей",
      genre: "Фантастика",
      price: 1120,
      image: "14.jpg",
      is_new: 1,
      telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
    }
  ];
  
  // Для каждой книги проверяем, существует ли она уже в базе данных
  books.forEach(book => {
    db.get('SELECT * FROM books WHERE title = ? AND author = ?', [book.title, book.author], (err, existingBook) => {
      if (err) {
        console.error('Ошибка при проверке существующей книги:', err.message);
        return;
      }
      
      // Если книги нет, добавляем её
      if (!existingBook) {
        db.run(
          'INSERT INTO books (title, author, genre, price, image, is_new, telegram_link) VALUES (?, ?, ?, ?, ?, ?, ?)',
          [book.title, book.author, book.genre, book.price, book.image, book.is_new, book.telegram_link],
          function(err) {
            if (err) {
              console.error(`Ошибка при добавлении книги "${book.title}":`, err.message);
            } else {
              console.log(`Добавлена книга: ${book.title}`);
            }
          }
        );
      } else if (!existingBook.telegram_link) {
        // Если книга существует, но нет ссылки на Telegram, обновляем её
        db.run(
          'UPDATE books SET telegram_link = ? WHERE id = ?',
          [book.telegram_link, existingBook.id],
          function(err) {
            if (err) {
              console.error(`Ошибка при обновлении ссылки для книги "${book.title}":`, err.message);
            } else {
              console.log(`Обновлена ссылка на Telegram для книги: ${book.title}`);
            }
          }
        );
      }
    });
  });
  
  console.log(`Проверено ${books.length} книг из статических страниц`);
}

// Функция для импорта книг из HTML-страниц (оставляем как запасной вариант)
function importBooksFromHTML() {
  try {
    console.log('Импорт книг из HTML-страниц...');
    
    // Импорт из index.html
    const indexHTML = fs.readFileSync('index.html', 'utf8');
    const indexDOM = new JSDOM(indexHTML);
    const indexDocument = indexDOM.window.document;
    
    // Получаем все карточки книг
    const indexBookCards = indexDocument.querySelectorAll('.book-card');
    const indexBooks = [];
    
    indexBookCards.forEach(card => {
      const img = card.querySelector('img');
      const title = card.querySelector('h3').textContent;
      const author = card.querySelector('.author').textContent;
      const genre = card.querySelector('.genre').textContent;
      const priceText = card.querySelector('.price').textContent;
      const price = parseFloat(priceText.replace(/[^\d.,]/g, '').replace(',', '.'));
      
      // Извлекаем имя файла изображения из src
      const imgSrc = img.getAttribute('src');
      const imageName = path.basename(imgSrc);
      
      indexBooks.push({
        title,
        author,
        genre,
        price,
        image: imageName,
        is_new: 0,
        telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
      });
    });
    
    // Импорт из catalog.html
    const catalogHTML = fs.readFileSync('catalog.html', 'utf8');
    const catalogDOM = new JSDOM(catalogHTML);
    const catalogDocument = catalogDOM.window.document;
    
    const catalogBookCards = catalogDocument.querySelectorAll('.book-card');
    const catalogBooks = [];
    
    catalogBookCards.forEach(card => {
      const img = card.querySelector('img');
      const title = card.querySelector('h3').textContent;
      const author = card.querySelector('.author').textContent;
      const genre = card.querySelector('.genre').textContent;
      const priceText = card.querySelector('.price').textContent;
      const price = parseFloat(priceText.replace(/[^\d.,]/g, '').replace(',', '.'));
      
      const imgSrc = img.getAttribute('src');
      const imageName = path.basename(imgSrc);
      
      // Проверяем, нет ли уже такой книги в списке
      const isDuplicate = indexBooks.some(book => book.title === title);
      
      if (!isDuplicate) {
        catalogBooks.push({
          title,
          author,
          genre,
          price,
          image: imageName,
          is_new: 0,
          telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
        });
      }
    });
    
    // Импорт из new.html
    const newHTML = fs.readFileSync('new.html', 'utf8');
    const newDOM = new JSDOM(newHTML);
    const newDocument = newDOM.window.document;
    
    const newBookCards = newDocument.querySelectorAll('.book-card');
    const newBooks = [];
    
    newBookCards.forEach(card => {
      const img = card.querySelector('img');
      const title = card.querySelector('h3').textContent;
      const author = card.querySelector('.author').textContent;
      const genre = card.querySelector('.genre').textContent;
      const priceText = card.querySelector('.price').textContent;
      const price = parseFloat(priceText.replace(/[^\d.,]/g, '').replace(',', '.'));
      
      const imgSrc = img.getAttribute('src');
      const imageName = path.basename(imgSrc);
      
      // Проверяем, нет ли уже такой книги в списке
      const isDuplicate = [...indexBooks, ...catalogBooks].some(book => book.title === title);
      
      if (!isDuplicate) {
        newBooks.push({
          title,
          author,
          genre,
          price,
          image: imageName,
          is_new: 1, // Отмечаем как новинку
          telegram_link: "https://t.me/+NsjEJ0bXWYE5MmRi"
        });
      }
    });
    
    // Объединяем все книги
    const allBooks = [...indexBooks, ...catalogBooks, ...newBooks];
    
    // Вставляем книги в базу данных
    const db = new sqlite3.Database('./bookstore.db');
    
    db.serialize(() => {
      // Подготавливаем запрос для вставки книг
      const stmt = db.prepare('INSERT INTO books (title, author, genre, price, image, is_new, telegram_link) VALUES (?, ?, ?, ?, ?, ?, ?)');
      
      allBooks.forEach(book => {
        stmt.run(book.title, book.author, book.genre, book.price, book.image, book.is_new, book.telegram_link);
      });
      
      stmt.finalize();
      
      console.log(`Импортировано ${allBooks.length} книг из HTML-страниц`);
    });
    
    db.close();
    
  } catch (error) {
    console.error('Ошибка при импорте книг из HTML:', error);
  }
}

// Открываем соединение с базой данных
const db = new sqlite3.Database('./bookstore.db', (err) => {
  if (err) {
    console.error('Ошибка при открытии базы данных:', err.message);
  } else {
    console.log('Соединение с базой данных установлено');
    
    // Создаем таблицы, если они не существуют
    db.serialize(() => {
      // Сначала проверим, существует ли таблица books
      db.get("SELECT name FROM sqlite_master WHERE type='table' AND name='books'", (err, table) => {
        if (err) {
          console.error('Ошибка при проверке таблицы books:', err.message);
          return;
        }
        
        // Если таблицы нет, создаем её и добавляем книги
        if (!table) {
          console.log('Создаем новую таблицу books');
          
          // Таблица книг
          db.run(`CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            genre TEXT NOT NULL,
            price REAL NOT NULL,
            image TEXT NOT NULL,
            is_new BOOLEAN DEFAULT 0,
            telegram_link TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
          )`, function(err) {
            if (err) {
              console.error('Ошибка при создании таблицы books:', err.message);
            } else {
              console.log('Таблица books создана');
              
              // Добавляем книги напрямую в базу данных
              addInitialBooks(db);
            }
          });
        } else {
          console.log('Таблица books уже существует');
          
          // Проверяем наличие поля telegram_link
          db.all("PRAGMA table_info(books)", (err, rows) => {
            if (err) {
              console.error('Ошибка при проверке структуры таблицы books:', err.message);
              return;
            }
            
            const hasTelegramLink = rows.some(row => row.name === 'telegram_link');
            
            // Если поля telegram_link нет, добавляем его
            if (!hasTelegramLink) {
              console.log('Добавляем поле telegram_link в таблицу books');
              db.run("ALTER TABLE books ADD COLUMN telegram_link TEXT", (err) => {
                if (err) {
                  console.error('Ошибка при добавлении поля telegram_link:', err.message);
                } else {
                  console.log('Поле telegram_link успешно добавлено');
                }
                
                // Добавляем книги из статических страниц в любом случае
                addInitialBooks(db);
              });
            } else {
              console.log('Поле telegram_link уже существует');
              
              // Проверяем, есть ли книги в таблице
              db.get('SELECT COUNT(*) as count FROM books', [], (err, row) => {
                if (err) {
                  console.error('Ошибка при чтении данных:', err.message);
                } else {
                  console.log(`В базе данных ${row.count} книг`);
                  
                  // Добавляем книги из статических страниц в любом случае,
                  // функция сама проверит наличие дубликатов и добавит только новые
                  addInitialBooks(db);
                }
              });
            }
          });
        }
      });
      
      // Таблица пользователей (администраторов)
      db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        is_admin BOOLEAN DEFAULT 0
      )`);
      
      // Проверяем, есть ли администратор в базе данных, и добавляем, если нет
      db.get('SELECT * FROM users WHERE is_admin = 1', [], async (err, row) => {
        if (err) {
          console.error('Ошибка при чтении данных:', err.message);
        } else if (!row) {
          // Создаем администратора по умолчанию
          const hashedPassword = await bcrypt.hash('admin123', 10);
          db.run('INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)', 
            ['admin', hashedPassword, 1], function(err) {
              if (err) {
                console.error('Ошибка при создании администратора:', err.message);
              } else {
                console.log('Создан администратор по умолчанию. Логин: admin, Пароль: admin123');
              }
            });
        }
      });
    });
  }
});

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: 'secret-key-for-bookis',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 3600000 } // 1 час
}));
app.use(express.static('.'));

// Middleware для проверки аутентификации
const isAuthenticated = (req, res, next) => {
  if (req.session.user && req.session.user.isAdmin) {
    next();
  } else {
    res.status(401).json({ message: 'Требуется аутентификация' });
  }
};

// Роуты для авторизации
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  
  db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
    if (err) {
      return res.status(500).json({ message: 'Ошибка сервера' });
    }
    
    if (!user) {
      return res.status(401).json({ message: 'Неверное имя пользователя или пароль' });
    }
    
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Неверное имя пользователя или пароль' });
    }
    
    req.session.user = { id: user.id, username: user.username, isAdmin: user.is_admin === 1 };
    res.json({ message: 'Авторизация успешна' });
  });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ message: 'Выход выполнен успешно' });
});

// API для работы с книгами
app.get('/api/books', (req, res) => {
  db.all('SELECT * FROM books ORDER BY id DESC', [], (err, rows) => {
    if (err) {
      return res.status(500).json({ message: 'Ошибка сервера', error: err.message });
    }
    res.json(rows);
  });
});

app.get('/api/books/:id', (req, res) => {
  const { id } = req.params;
  db.get('SELECT * FROM books WHERE id = ?', [id], (err, row) => {
    if (err) {
      return res.status(500).json({ message: 'Ошибка сервера', error: err.message });
    }
    if (!row) {
      return res.status(404).json({ message: 'Книга не найдена' });
    }
    res.json(row);
  });
});

app.post('/api/books', isAuthenticated, upload.single('image'), (req, res) => {
  const { title, author, genre, price, is_new, telegram_link } = req.body;
  const image = req.file ? req.file.filename : '';
  
  if (!title || !author || !genre || !price || !image) {
    return res.status(400).json({ message: 'Все поля обязательны для заполнения' });
  }
  
  const isNewValue = is_new ? 1 : 0;
  
  db.run(
    'INSERT INTO books (title, author, genre, price, image, is_new, telegram_link) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [title, author, genre, price, image, isNewValue, telegram_link || null],
    function(err) {
      if (err) {
        return res.status(500).json({ message: 'Ошибка сервера', error: err.message });
      }
      res.status(201).json({ id: this.lastID, message: 'Книга успешно добавлена' });
    }
  );
});

app.put('/api/books/:id', isAuthenticated, upload.single('image'), (req, res) => {
  const { id } = req.params;
  const { title, author, genre, price, is_new, telegram_link } = req.body;
  const isNewValue = is_new ? 1 : 0;
  
  if (!title || !author || !genre || !price) {
    return res.status(400).json({ message: 'Все поля обязательны для заполнения' });
  }
  
  // Сначала получаем существующую запись, чтобы не перезаписать изображение, если новое не загружено
  db.get('SELECT * FROM books WHERE id = ?', [id], (err, book) => {
    if (err) {
      return res.status(500).json({ message: 'Ошибка сервера', error: err.message });
    }
    
    if (!book) {
      return res.status(404).json({ message: 'Книга не найдена' });
    }
    
    const image = req.file ? req.file.filename : book.image;
    
    db.run(
      'UPDATE books SET title = ?, author = ?, genre = ?, price = ?, image = ?, is_new = ?, telegram_link = ? WHERE id = ?',
      [title, author, genre, price, image, isNewValue, telegram_link || null, id],
      function(err) {
        if (err) {
          return res.status(500).json({ message: 'Ошибка сервера', error: err.message });
        }
        res.json({ message: 'Книга успешно обновлена' });
      }
    );
  });
});

app.delete('/api/books/:id', isAuthenticated, (req, res) => {
  const { id } = req.params;
  
  // Сначала получаем информацию о книге, чтобы удалить файл изображения
  db.get('SELECT * FROM books WHERE id = ?', [id], (err, book) => {
    if (err) {
      return res.status(500).json({ message: 'Ошибка сервера', error: err.message });
    }
    
    if (!book) {
      return res.status(404).json({ message: 'Книга не найдена' });
    }
    
    db.run('DELETE FROM books WHERE id = ?', [id], function(err) {
      if (err) {
        return res.status(500).json({ message: 'Ошибка сервера', error: err.message });
      }
      
      // Удаляем файл изображения, если он существует и не используется в других книгах
      // Не удаляем файлы с изображениями из оригинального каталога
      const imagePath = path.join(__dirname, 'books', book.image);
      const isOriginalImage = !book.image.includes('-'); // Простой способ определить оригинальные изображения
      
      if (!isOriginalImage && fs.existsSync(imagePath)) {
        // Проверяем, используется ли изображение в других книгах
        db.get('SELECT COUNT(*) as count FROM books WHERE image = ? AND id != ?', [book.image, id], (err, row) => {
          if (!err && row.count === 0) {
            try {
              fs.unlinkSync(imagePath);
              console.log(`Удален файл изображения: ${book.image}`);
            } catch (error) {
              console.error(`Ошибка при удалении файла ${imagePath}:`, error);
            }
          }
        });
      }
      
      // После удаления книги проверяем и оптимизируем последовательность автоинкремента
      // Но не делаем это сразу, а только после нескольких удалений
      db.get('SELECT COUNT(*) as count FROM books', [], (err, result) => {
        if (!err) {
          const bookCount = result.count;
          db.get("SELECT seq FROM sqlite_sequence WHERE name = 'books'", [], (err, sequence) => {
            if (!err && sequence && (sequence.seq > bookCount + 5)) {
              // Если разница между последним ID и количеством книг слишком большая, оптимизируем
              optimizeAutoIncrement();
            }
          });
        }
      });
      
      res.json({ message: 'Книга успешно удалена' });
    });
  });
});

// Обработка запросов к HTML-страницам
app.get('/admin', (req, res) => {
  if (req.session.user && req.session.user.isAdmin) {
    res.sendFile(path.join(__dirname, 'admin.html'));
  } else {
    res.redirect('/auth.html');
  }
});

// Функция для проверки и оптимизации автоинкремента в таблице books
function optimizeAutoIncrement() {
  console.log('Проверка состояния автоинкремента в таблице books...');

  // Получаем максимальный ID из таблицы книг
  db.get('SELECT MAX(id) as max_id FROM books', [], (err, result) => {
    if (err) {
      console.error('Ошибка при проверке максимального ID:', err.message);
      return;
    }

    const maxId = result.max_id || 0;
    console.log(`Текущее максимальное значение ID: ${maxId}`);

    // Получаем текущее значение sqlite_sequence для таблицы books
    db.get("SELECT seq FROM sqlite_sequence WHERE name = 'books'", [], (err, sequence) => {
      if (err) {
        console.error('Ошибка при проверке последовательности:', err.message);
        return;
      }

      // Если последовательность существует и её значение больше максимального ID на значительную величину,
      // сбрасываем её до текущего максимального ID
      if (sequence && sequence.seq > maxId + 10) {
        console.log(`Сброс последовательности автоинкремента с ${sequence.seq} до ${maxId}`);
        db.run("UPDATE sqlite_sequence SET seq = ? WHERE name = 'books'", [maxId], function(err) {
          if (err) {
            console.error('Ошибка при обновлении последовательности:', err.message);
          } else {
            console.log('Последовательность автоинкремента успешно обновлена');
          }
        });
      } else {
        console.log('Последовательность автоинкремента в нормальном состоянии');
      }
    });
  });
}

// Запуск сервера
app.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
  
  // Запускаем оптимизацию автоинкремента при старте сервера
  optimizeAutoIncrement();
}); 